class Lecturer extends Teacher{
    String Department;
    int yearsOfExperience;
    int gradedScore;
    boolean hasGraded;
    

    public Lecturer(int TeacherId, String TeacherName, String Address,
    String WorkType, String EmploymentStatus,String department,int yearsOfExperience){
        super(TeacherId,TeacherName,Address,WorkType,EmploymentStatus);
        setWorkHour(5);
        this.Department = Department;
        this.yearsOfExperience = yearsOfExperience;
        this.gradedScore = 0;
        this.hasGraded = false;
    }
    
        public String getDepartment(){
        return Department;
    }
    
    public int getYearsOfExperience(){
        return yearsOfExperience;
    }
    
    public int getGradedScore(){
        return gradedScore;
    }
    
    public boolean getHasGraded(){
        return hasGraded;
    }
    
  
    public void setGradedScore(int gradedScore){
        this.gradedScore = gradedScore;
    }
    
    public void gradedAssignment(int gradedScore, String department,
    int yearsOfExperience){
        if(hasGraded != true && yearsOfExperience >= 5 && department.equals(this.Department))
        {
            if(gradedScore >= 70)
            System.out.println("Grade: A");
            else if(gradedScore >= 60)
            System.out.println("Grade: B");
            else if(gradedScore >= 50)
            System.out.println("Grade: C");
            else if(gradedScore >= 40)
            System.out.println("Grade: D");
            else 
            System.out.println("Grade: E");
            
            hasGraded = true;
        }
        else{
            System.out.println("Either already graded or not eligible.");
        }
    }
    
  
    public void display(){
        super.display();
        
        System.out.println("department: "+ getDepartment());
        System.out.println("yearsOfExperience: "+ getYearsOfExperience());
        System.out.println("gradedScore: "+ getGradedScore());
    }
}