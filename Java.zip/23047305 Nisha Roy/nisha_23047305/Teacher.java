class Teacher{
    int Id;
    String Name;
    String address;
    String workType;
    String employmentStatus;
    int workHour;
    
    //constructor with the given parameters is made
    public Teacher(int TeacherId, String TeacherName, String Address,
    String WorkType, String EmploymentStatus){
        this.Id = TeacherId;
        this.Name = TeacherName;
        this.address = Address;
        this.workType = WorkType;
        this.employmentStatus = EmploymentStatus;
    }
    
   
    public int getTeacherID(){
        return this.Id;
    }
    
    
    public String getTeacherName(){
        return this.Name;
    }
    
    public String getAddress(){
        return this.address;
    }
    
    
    public String getWorkType(){
        return this.workType;
    }
    
   
    public String getEmploymentStatus(){
        return this.employmentStatus;
    }
    
    
    public int getWorkHour(){
        return this.workHour;
    }
    
   
    public void  setWorkHour(int workHour){
        this.workHour = workHour;
    }
    
    
    
    public void display(){
        System.out.println("TeacherID: "+ getTeacherID());
        System.out.println("TeacherName: "+ getTeacherName());
        System.out.println("Address: "+ getAddress());
        System.out.println("Work Type: "+ getWorkType());
        System.out.println("Employment Status: "+ getEmploymentStatus());

        
        if(workHour!=0){
            System.out.println("Work Hour: " + workHour );
        }
        else{
            System.out.println("A part timer");
        }
    }
}
