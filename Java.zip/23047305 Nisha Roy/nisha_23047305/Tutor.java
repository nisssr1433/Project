


class Tutor extends Teacher{
    private double salary;
    private String specialization;
    private String AcademicQualification;
    private int performenceIndex;
    private boolean isCertified;
    
    public Tutor(int teacherId,String teacherName,String address,
    String workType,String employmentStatus,int workHour,
    double salary,String specialization,String academicQualification,
    int performenceIndex){
    
     super(teacherId,teacherName,address,workType,employmentStatus);
     super.setWorkHour(5);
     
     this.salary = salary;
     this.specialization = specialization;
     this.AcademicQualification = academicQualification;
     this.performenceIndex = performenceIndex;
     this.isCertified = false;
}



public double getSalary(){
    return salary;
}

public String getSpecialization(){
    return specialization;
}

public String getAcademicQualification(){
    return AcademicQualification;
}

public int getPerformenceIndex(){
    return performenceIndex;
}

public boolean getIsCertified(){
    return isCertified;
}



public void setSalary(int salary){
    if(isCertified && performenceIndex >= 5 && workHour >=20){
       
        if(performenceIndex >=5 && performenceIndex <=7)
        System.out.println("appraised salary: "+salary + 0.05 * salary);
        
        else if(performenceIndex >=8 && performenceIndex <=9)
        System.out.println("appraised salary: "+salary + 0.1 * salary);
        
        else if(performenceIndex== 10)
        System.out.println("appraised salary: "+salary + 0.2 * salary);
    
    else{
        System.out.println("not qualified for appraisal");
    }
    isCertified = true;
}
else{
    System.out.println("Tutor not certified or not qualifed");
}   
}

public void removeTutor(){
    if(isCertified = false){
        this.salary = 0;
        this.specialization = null;
        this.AcademicQualification = null;
        this.performenceIndex = 0;
        
        isCertified = false;
    }
}


public void display(){
    if(isCertified = false){
        super.display();
    }
    else{
        super.display();
        System.out.println("Salary: " + getSalary());
        System.out.println("specialization: " + getSpecialization());
        System.out.println("academicQualification: " 
        + getAcademicQualification());
        System.out.println("performenceIndex: " + getPerformenceIndex());
    }
}
}





