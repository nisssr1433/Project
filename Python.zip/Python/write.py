import os

def update_products_file(file_name, products):
    try:
        with open(file_name, 'w') as file:
            for name, details in products.items():
                line = f"{name},{details['brand']},{details['quantity']},{details['cost']},{details['country']}\n"
                file.write(line)
    except IOError:
        print(f"Error: Unable to update file '{file_name}'.")
