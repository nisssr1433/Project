import os
import datetime
from read import read_products
from write import update_products_file
from operations import generate_invoice, purchase_product, sell_product

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
PRODUCT_FILE = os.path.join(BASE_DIR, 'products.txt')

def display_products(products):
    print("\n--- Available Products ---")
    print("{:<5} {:<25} {:<15} {:<10} {:<10} {:<15}".format("SN", "Product", "Brand", "Qty", "Price", "Country"))
    print("-" * 60)
    for idx, (product_name, details) in enumerate(products.items()):
        print("{:<5} {:<25} {:<15} {:<10} {:<10} {:<15}".format(
            idx, product_name, details['brand'], details['quantity'], details['cost']*2, details['country']))
    print("-" * 60)

def main():
    products = read_products(PRODUCT_FILE)

    while True:
        print("\n--- WeCare Skin Care Product System ---")
        print("1. Display Products")
        print("2. Buy Product")
        print("3. Sell Product")
        print("4. Exit")
        choice = input("Enter your choice (1-4): ")

        if choice == '1':
            display_products(products)

        elif choice == '2':
            customer = input("Enter customer name: ")
            transaction_items = []
            while True:
                display_products(products)
                product_sn = input("Enter product SN to buy (or 'done' to finish): ").lower()
                if product_sn == 'done':
                    break
                if not product_sn.isdigit():
                    print("Invalid input. Please enter a valid product number.")
                    continue
                sn = int(product_sn)
                if sn < 0 or sn >= len(products):
                    print("Invalid product number.")
                    continue
                product_name = list(products.keys())[sn]
                qty_input = input(f"Enter quantity of {product_name} to buy: ")
                if not qty_input.isdigit():
                    print("Invalid quantity.")
                    continue
                qty = int(qty_input)
                available = products[product_name]['quantity']
                if qty > available:
                    print(f"Not enough stock. Available: {available}")
                    continue
                sell_product(products, product_name, qty)
                transaction_items.append((product_name, qty))

            date = datetime.datetime.now().strftime("%d-%m-%Y")
            invoice_file = os.path.join(BASE_DIR, f"invoice_{customer.replace(' ', '_')}_{date}.txt")
            generate_invoice(invoice_file, transaction_items, products, date, customer=customer)
            update_products_file(PRODUCT_FILE, products)
            print("Purchase completed. Invoice generated.")

        elif choice == '3':
            supplier = input("Enter supplier name: ")
            restock_items = []
            while True:
                product_name = input("Enter product name to restock (or 'done'): ")
                if product_name.lower() == 'done':
                    break
                brand = input("Enter brand: ")
                qty_input = input("Enter quantity: ")
                cost_input = input("Enter cost per item: ")
                if not (qty_input.isdigit() and cost_input.isdigit()):
                    print("Invalid input. Please enter numeric values for quantity and cost.")
                    continue
                qty = int(qty_input)
                cost = int(cost_input)
                country = input("Enter country: ")
                if product_name in products:
                    purchase_product(products, product_name, qty)
                else:
                    products[product_name] = {
                        'brand': brand,
                        'quantity': qty,
                        'cost': cost,
                        'country': country
                    }
                restock_items.append((product_name, qty))

            date = datetime.datetime.now().strftime("%d-%m-%Y")
            invoice_file = os.path.join(BASE_DIR, f"restock_invoice_{supplier.replace(' ', '_')}_{date}.txt")
            generate_invoice(invoice_file, restock_items, products, date, supplier=supplier)
            update_products_file(PRODUCT_FILE, products)
            print("Restock completed. Invoice generated.")

        elif choice == '4':
            print("Exiting system.")
            break
        else:
            print("Invalid option. Please select from 1 to 4.")

if __name__ == '__main__':
    main()
    input("\nPress Enter to exit...")
