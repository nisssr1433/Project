import os

def read_products(file_name):
    products = {}
    try:
        with open(file_name, 'r') as file:
            for line in file:
                line = line.strip()
                details = line.split(',')
                if len(details) != 5:
                    print(f"Skipping malformed line: {line}")
                    continue
                name, brand, quantity, cost, country = details
                try:
                    products[name] = {
                        'brand': brand,
                        'quantity': int(quantity),
                        'cost': int(cost),
                        'country': country
                    }
                except ValueError:
                    print(f"Invalid quantity/cost in line: {line}")
    except IOError:
        print(f"Error: File '{file_name}' not found.")
    return products
