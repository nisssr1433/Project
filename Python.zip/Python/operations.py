import datetime

def generate_invoice(file_name, transaction_items, products, date, customer=None, supplier=None):
    try:
        with open(file_name, 'w') as file:
            if customer:
                file.write(f"Invoice for {customer}\n")
            if supplier:
                file.write(f"Restock Invoice for {supplier}\n")
            file.write(f"Date: {date}\n")
            file.write("{:<25} {:<10} {:<15} {:<10}\n".format("Product", "Qty", "Unit Price", "Total"))
            file.write("-" * 60 + "\n")

            total = 0
            for item in transaction_items:
                name = item[0]
                qty = item[1]
                unit_price = products[name]['cost'] * 2
                line_total = unit_price * qty
                total += line_total
                file.write(f"{name:<25} {qty:<10} {unit_price:<15} {line_total:<10}\n")

            file.write("-" * 60 + "\n")
            file.write(f"Total Amount: Rs. {total}\n")
    except IOError:
        print(f"Error: Unable to write the invoice file '{file_name}'.")

def purchase_product(products, product_name, quantity):
    if product_name in products:
        products[product_name]['quantity'] += quantity
    else:
        print("Product does not exist in the inventory.")

def sell_product(products, product_name, quantity):
    if product_name in products and products[product_name]['quantity'] >= quantity:
        products[product_name]['quantity'] -= quantity
    else:
        print("Insufficient stock or product not found.")
